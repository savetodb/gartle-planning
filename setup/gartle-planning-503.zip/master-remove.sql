USE master;
GO

DROP USER pa_admin_01;
GO

DROP USER pa_analyst_01;
GO

DROP USER pa_developer_01;
GO

DROP USER pa_user_01;
GO

DROP USER pa_user_101;
GO

DROP USER pa_user_201;
GO

DROP USER pa_user_301;
GO

DROP USER pa_user_401;
GO


DROP LOGIN pa_admin_01;
GO

DROP LOGIN pa_analyst_01;
GO

DROP LOGIN pa_developer_01;
GO

DROP LOGIN pa_user_01;
GO

DROP LOGIN pa_user_101;
GO

DROP LOGIN pa_user_201;
GO

DROP LOGIN pa_user_301;
GO

DROP LOGIN pa_user_401;
GO

